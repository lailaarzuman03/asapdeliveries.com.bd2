<section class="vc_custom_1488798316120 mkd-parallax-section-holder" style="background-image: url(<?php echo base_url("resource/images/h1-parallax-4.png"); ?>);background-position: 50% -13px;color:#fff;">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
					<h1 class="h1">Subscribe to our Newsletter</h1>
					<div class="mkd-separator-holder clearfix">
						<div class="mkd-separator" style="border-color: #f05034;border-style: solid;width: 75px;border-bottom-width: 2px"></div>
					</div>					
					<br><br><br>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
					<form class="form-inline">
					  <div class="form-group">					  
					    <input type="text" class="form-control" id="exampleInputName2" placeholder="Jane Doe" style="height: 48px;border-radius: 0px;">
					  </div>
					  <div class="form-group">
					    <input type="email" class="form-control" id="exampleInputEmail2" placeholder="jane.doe@example.com" style="height: 48px;border-radius: 0px;">
					  </div>
					  <button type="submit" class="btn btn-lg btn-primary" style="border-radius: 0px;background-color: #f05034;border:1px solid #f05034;">Subscribe  </button>
					</form>
				</div>
			</div><br><br>
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 text-center">
					<a href="https://www.facebook.com/asapdeliveriesbd" target="_blank" class="social-icon-hover">
						<i class="fab fa-facebook fa-5x"></i>
						<h3>Facebook</h3>
						<div class="mkd-separator-holder clearfix">
							<div class="mkd-separator" style="border-color: #f05034;border-style: solid;width: 75px;border-bottom-width: 2px"></div>
						</div>
					</a>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 text-center">
					<a href="https://www.instagram.com/asapdeliveriesbd/" target="_blank" class="social-icon-hover">
						<i class="fab fa-instagram fa-5x"></i>
						<h3>Iinstagram</h3>
						<div class="mkd-separator-holder clearfix">
							<div class="mkd-separator" style="border-color: #f05034;border-style: solid;width: 75px;border-bottom-width: 2px"></div>
						</div>
					</a>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 text-center">
					<a href="https://www.linkedin.com/company/asapdeliveriesbd/" target="_blank" class="social-icon-hover">
						<i class="fab fa-linkedin fa-5x"></i>
						<h3>Linkedin</h3>
						<div class="mkd-separator-holder clearfix">
							<div class="mkd-separator" style="border-color: #f05034;border-style: solid;width: 75px;border-bottom-width: 2px"></div>
						</div>
					</a>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 text-center">
					<a href="https://www.youtube.com/channel/UCj4I45OBwAQzjrQgZCqRDWA" target="_blank" class="social-icon-hover">
						<i class="fab fa-youtube fa-5x"></i>
						<h3>Youtube</h3>
						<div class="mkd-separator-holder clearfix">
							<div class="mkd-separator" style="border-color: #f05034;border-style: solid;width: 75px;border-bottom-width: 2px"></div>
						</div>
					</a>
				</div>
			</div>
		</div>
	</section>