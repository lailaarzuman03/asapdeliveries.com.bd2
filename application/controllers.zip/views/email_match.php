<?php 
	if(!empty($findMailValue)) {
	     echo "<p style='color:#ff0909'> This E-mail address is already exists ! </p>";
	  }

	  if (!empty($find_client_user_nameValue)) {
	  	 echo "<p style='color:#ff0909'> This User Name is already exists ! </p>";
	  }
?>