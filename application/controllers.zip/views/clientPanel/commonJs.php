<!-- jQuery -->
<script src="<?php echo base_url("resource/vendors/jquery/dist/jquery.min.js"); ?>"></script>
<!-- Bootstrap -->
<script src="<?php echo base_url("resource/vendors/bootstrap/dist/js/bootstrap.min.js"); ?>"></script>
<!-- FastClick -->
<script src="<?php echo base_url("resource/vendors/fastclick/lib/fastclick.js"); ?>"></script>
<!-- NProgress -->
<script src="<?php echo base_url("resource/vendors/nprogress/nprogress.js"); ?>"></script>
<!-- bootstrap-progressbar -->
<script src="<?php echo base_url("resource/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"); ?>"></script>
<!-- iCheck -->
<script src="<?php echo base_url("resource/vendors/iCheck/icheck.min.js"); ?>"></script>
<!-- bootstrap-daterangepicker -->
<script src="<?php echo base_url("resource/vendors/moment/min/moment.min.js"); ?>"></script>
<script src="<?php echo base_url("resource/vendors/bootstrap-daterangepicker/daterangepicker.js"); ?>"></script>
<!-- bootstrap-wysiwyg -->
<script src="<?php echo base_url("resource/vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"); ?>"></script>
<script src="<?php echo base_url("resource/vendors/jquery.hotkeys/jquery.hotkeys.js"); ?>"></script>
<script src="<?php echo base_url("resource/vendors/google-code-prettify/src/prettify.js"); ?>"></script>
<!-- jQuery Tags Input -->
<script src="<?php echo base_url("resource/vendors/jquery.tagsinput/src/jquery.tagsinput.js"); ?>"></script>
<!-- Switchery -->
<script src="<?php echo base_url("resource/vendors/switchery/dist/switchery.min.js"); ?>"></script>
<!-- Select2 -->
<script src="<?php echo base_url("resource/vendors/select2/dist/js/select2.full.min.js"); ?>"></script>
<!-- Parsley -->
<script src="<?php echo base_url("resource/vendors/parsleyjs/dist/parsley.min.js"); ?>"></script>
<!-- Autosize -->
<script src="<?php echo base_url("resource/vendors/autosize/dist/autosize.min.js"); ?>"></script>
<!-- jQuery autocomplete -->
<script src="<?php echo base_url("resource/vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"); ?>"></script>
<!-- starrr -->
<script src="<?php echo base_url("resource/vendors/starrr/dist/starrr.js"); ?>"></script>

<!-- Custom Theme Scripts -->
<script src="<?php echo base_url("resource/build/js/custom.min.js"); ?>"></script>
