 <!-- Bootstrap -->
    <link href="<?php echo base_url("resource/vendors/bootstrap/dist/css/bootstrap.min.css"); ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url("resource/vendors/font-awesome/css/font-awesome.min.css"); ?>" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo base_url("resource/vendors/nprogress/nprogress.css"); ?>" rel="stylesheet">
    <!-- iCheck -->
    <link href="<?php echo base_url("resource/vendors/iCheck/skins/flat/green.css"); ?>" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="<?php echo base_url("resource/vendors/google-code-prettify/bin/prettify.min.css"); ?>" rel="stylesheet">
    <!-- Select2 -->
    <link href="<?php echo base_url("resource/vendors/select2/dist/css/select2.min.css"); ?>" rel="stylesheet">
    <!-- Switchery -->
    <link href="<?php echo base_url("resource/vendors/switchery/dist/switchery.min.css"); ?>" rel="stylesheet">
    <!-- starrr -->
    <link href="<?php echo base_url("resource/vendors/starrr/dist/starrr.css"); ?>" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="<?php echo base_url("resource/vendors/bootstrap-daterangepicker/daterangepicker.css"); ?>" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo base_url("resource/build/css/custom.min.css"); ?>" rel="stylesheet">