<footer>
  <div class="pull-right">
  Web Application Software © 2017 GloballyTec.com - All Rights Reserved 
  </div>
  <div class="clearfix"></div>
</footer>
