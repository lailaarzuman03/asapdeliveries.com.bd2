<table class="table table-bordered table-striped" width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                      <td valign="middle" align="center" class="info">Merchant name</td>
                      <td>
                         <table class="table table-condensed table-bordered table-hover table-striped" width="100%" cellpadding="0" cellspacing="0">
                          <tr class="info">
                            <td>Order number</td>
                            <td>Client name</td>
                            <td>Client number</td>
                            <td>Delivery date</td>
                            <td>Amount collected</td>
                            <td>Shipping charge</td>
                            <td>COD</td>
                            <td>Merchant receivable</td>          
                          </tr>
                          <tr>
                            <td>ASAP#00000201</td>
                            <td>Prince</td>
                            <td>01774273726</td>
                            <td>03/17/2018</td>
                            <td>2000</td>
                            <td>60</td>
                            <td>20</td>
                            <td>1920</td>
                          </tr>
                          <tr>
                            <td>ASAP#00000201</td>
                            <td>Prince</td>
                            <td>01774273726</td>
                            <td>03/17/2018</td>
                            <td>2000</td>
                            <td>60</td>
                            <td>20</td>
                            <td>1920</td>
                          </tr>
                          <tr>
                            <td>ASAP#00000201</td>
                            <td>Prince</td>
                            <td>01774273726</td>
                            <td>03/17/2018</td>
                            <td>2000</td>
                            <td>60</td>
                            <td>20</td>
                            <td>1920</td>
                          </tr>
                          <tr>
                            <td>ASAP#00000201</td>
                            <td>Prince</td>
                            <td>01774273726</td>
                            <td>03/17/2018</td>
                            <td>2000</td>
                            <td>60</td>
                            <td>20</td>
                            <td>1920</td>
                          </tr>
                          <tr>
                            <td>ASAP#00000201</td>
                            <td>Prince</td>
                            <td>01774273726</td>
                            <td>03/17/2018</td>
                            <td>2000</td>
                            <td>60</td>
                            <td>20</td>
                            <td>1920</td>
                          </tr>
                          <tr>
                            <td>ASAP#00000201</td>
                            <td>Prince</td>
                            <td>01774273726</td>
                            <td>03/17/2018</td>
                            <td>2000</td>
                            <td>60</td>
                            <td>20</td>
                            <td>1920</td>
                          </tr>
                          <tr class="success">
                            <td colspan="7" align="right" style="font-weight: bold;">Total </td>
                            <td align="left" style="font-weight: bold;">20000</td>
                          </tr>
                        </table>
                      </td>
                    </tr><tr>
                      <td valign="middle" align="center" class="info">Merchant name</td>
                      <td>
                         <table class="table table-condensed table-bordered table-hover table-striped" width="100%" cellpadding="0" cellspacing="0">
                          <tr class="info">
                            <td>Order number</td>
                            <td>Client name</td>
                            <td>Client number</td>
                            <td>Delivery date</td>
                            <td>Amount collected</td>
                            <td>Shipping charge</td>
                            <td>COD</td>
                            <td>Merchant receivable</td>          
                          </tr>
                          <tr>
                            <td>ASAP#00000201</td>
                            <td>Prince</td>
                            <td>01774273726</td>
                            <td>03/17/2018</td>
                            <td>2000</td>
                            <td>60</td>
                            <td>20</td>
                            <td>1920</td>
                          </tr>
                          <tr>
                            <td>ASAP#00000201</td>
                            <td>Prince</td>
                            <td>01774273726</td>
                            <td>03/17/2018</td>
                            <td>2000</td>
                            <td>60</td>
                            <td>20</td>
                            <td>1920</td>
                          </tr>
                          <tr>
                            <td>ASAP#00000201</td>
                            <td>Prince</td>
                            <td>01774273726</td>
                            <td>03/17/2018</td>
                            <td>2000</td>
                            <td>60</td>
                            <td>20</td>
                            <td>1920</td>
                          </tr>
                          <tr>
                            <td>ASAP#00000201</td>
                            <td>Prince</td>
                            <td>01774273726</td>
                            <td>03/17/2018</td>
                            <td>2000</td>
                            <td>60</td>
                            <td>20</td>
                            <td>1920</td>
                          </tr>
                          <tr>
                            <td>ASAP#00000201</td>
                            <td>Prince</td>
                            <td>01774273726</td>
                            <td>03/17/2018</td>
                            <td>2000</td>
                            <td>60</td>
                            <td>20</td>
                            <td>1920</td>
                          </tr>
                          <tr>
                            <td>ASAP#00000201</td>
                            <td>Prince</td>
                            <td>01774273726</td>
                            <td>03/17/2018</td>
                            <td>2000</td>
                            <td>60</td>
                            <td>20</td>
                            <td>1920</td>
                          </tr>
                          <tr class="success">
                            <td colspan="7" align="right" style="font-weight: bold;">Total </td>
                            <td align="left" style="font-weight: bold;">20000</td>
                          </tr>
                        </table>
                      </td>
                    </tr>
                  </table>  