<table class="table table-bordered table-hover">
  <tr>
    <td>  <label for="business_name">Business Name : </label> &nbsp; <?php echo $findRowValue->business_name; ?> </td>
    <td> <label for="full_name">Facebook Page URL  : </label> &nbsp; <?php echo $findRowValue->facebook_url; ?></td>
  </tr>
  <tr>
    <td> <label for="full_name">Full Name : </label> &nbsp; <?php echo $findRowValue->full_name; ?></td>
    <td>  <label for="business_name">Login userName  : </label> &nbsp; <?php echo $findRowValue->client_user_name; ?> </td>
  </tr>
  <tr>
    <td> <label for="mobile">Phone or Mobile </label> &nbsp; <?php echo $findRowValue->mobile; ?> </td>
    <td> <label for="full_name">Password : </label> &nbsp; <?php echo $findRowValue->cpassword; ?></td>
  </tr>
  <tr>
    <td>  <label for="business_name">E-mail Address : </label> &nbsp; <?php echo $findRowValue->email; ?> </td>
    <td> <label for="full_name">Payment Method : </label> &nbsp; <?php echo $findRowValue->payment_method; ?></td>
  </tr>
  <tr>
    <td>  <label for="business_name">City : </label> &nbsp; <?php echo $findRowValue->city_id; ?> </td>
    <td> <label for="full_name">Payment Details  : </label> &nbsp; <?php echo $findRowValue->payment_details; ?></td>
  </tr>
  <tr>
    <td colspan="2">  <label for="business_name">Address : </label> &nbsp; <?php echo $findRowValue->address; ?> </td>
  </tr>
</table> 