<div class="top_nav">
  <div class="nav_menu">
    <nav>
      <div class="nav toggle">
        <a id="menu_toggle"><i class="fa fa-bars"></i></a>
      </div>

      <ul class="nav navbar-nav navbar-right">
        <li class="">
          <a href="<?php echo site_url('backend/login/logout/')?>" class="user-profile">
            <i class="fa fa-power-off"></i>
          </a>
        </li>
      </ul>
    </nav>
  </div>
</div>
