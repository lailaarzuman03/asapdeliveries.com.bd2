<section style="background-color: #222222;color: #fff;font-weight: bold;padding: 10px;">
	<div class="container">
		<!-- <div class="row">
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<h3>About Company</h3>
				<div class="mkd-separator-holder clearfix">
					<div class="mkd-separator" style="border-color: #f05034;border-style: solid;width: 75px;border-bottom-width: 2px"></div>
				</div>
				<a href="#" class="link"> Company History </a>
				<a href="#" class="link"> About Us </a>
				<a href="#" class="link"> Our Team</a>
				<a href="#" class="link"> Our Process </a>
				<a href="#" class="link"> Our Projects </a>
				<a href="#" class="link"> Pricing Plans </a>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<h3>Useful Information</h3>
				<div class="mkd-separator-holder clearfix">
					<div class="mkd-separator" style="border-color: #f05034;border-style: solid;width: 75px;border-bottom-width: 2px"></div>
				</div>
				<a href="#" class="link"> Contact Us </a>
				<a href="#" class="link"> Our Clients </a>
				<a href="#" class="link"> FAQ</a>
				<a href="#" class="link"> Get In Touch </a>
				<a href="#" class="link"> Product List </a>
				<a href="#" class="link"> Pricing Plans </a>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<h3>Additional Links</h3>
				<div class="mkd-separator-holder clearfix">
					<div class="mkd-separator" style="border-color: #f05034;border-style: solid;width: 75px;border-bottom-width: 2px"></div>
				</div>
				<a href="#" class="link"> Latest Posts </a>
				<a href="#" class="link"> Coming Soon </a>
				<a href="#" class="link"> About Us – Parallax</a>
				<a href="#" class="link"> Cart </a>
				<a href="#" class="link"> Checkout </a>
				<a href="#" class="link"> Wishlist </a>
			</div>
		 -->
		<!-- <div class="row">
			<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
				<a href="#">
					<img src="<?php echo base_url("resource/images/asap-L.png") ?>" alt="" class="img-resonsive">
			    </a>
			</div>
			<div class="col-lg-6 col-md-6 col-sm-8 col-xs-12">
				<h3>About Our Company</h3>
				<p align="justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae quis quod libero consequatur eius doloremque perferendis, facere at earum aspernatur perspiciatis doloribus laboriosam corporis beatae, saepe, sed unde officia explicabo.</p>
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
				<h3>Check Out The Best Discounts</h3>
				<a href="" class="btn btn-lg btn-default" style="border-radius: 0px;color: rgb(255, 255, 255);background-color: rgb(69, 69, 69);border-color: rgb(69, 69, 69);">Discounts</a>
			</div>
		</div> -->
		<div class="row">			
			<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
				<p align="left">Copyright 2018 © www.asapdeliveries.com.bd</p>
			</div>			
			<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
				<p align="right"> Privacy Policy &nbsp;  ||  &nbsp; Terms and Condition</p>
			</div>
		</div>
	</div>
</section>