
 <div class="row" style="background: #1b1b1b;color: #fff;padding:5px;margin:0px;">
	<div class="container">
		<div class="row" style="height: 40px;vertical-align: middle;margin-bottom: 10px;">
			<div class="col-ld-7 col-md-7 col-sm-12 col-xs-12 text-left">
				<span class="glyphicon glyphicon-earphone"></span> &nbsp; + 880167 5583010
				&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#96a0ab;">|</span>  &nbsp;&nbsp; &nbsp;&nbsp;
				<i class="fas fa-clock"></i> Sat - Thur 10:00 - 18:00 / Closed on Friday
			</div>
			<div class="col-ld-5 col-md-5 col-sm-12 col-xs-12">
				<div class="social pull-right">
					<a title="asapdeliveries.com.bd" target="_blank" href="https://www.facebook.com/asapdeliveriesbd">
				   		<i class="fa fa-facebook facebook1"></i> 
				   	</a>				   	
				  	<a title="asapdeliveries.com.bd" target="_blank" href="https://www.youtube.com/channel/UCj4I45OBwAQzjrQgZCqRDWA">
				  		<i class="fa fa-youtube youtube1"></i> 
				  	</a>		
				    <a title="asapdeliveries.com.bd" target="_blank" href="https://www.linkedin.com/company/asapdeliveriesbd/">
					   <i class="fa fa-linkedin linkedin1 "></i> 
				    </a>
				 	<a title="asapdeliveries.com.bd" target="_blank" href="https://www.instagram.com/asapdeliveriesbd/">
				 		<i class="fa fa-instagram instagram1"></i> 
				 	</a>
				</div>
			</div>
		</div>
	</div>
</div>