<section class="vc_custom_1488798316120 mkd-parallax-section-holder" style="background-image: url(<?php echo base_url("resource/images/h1-parallax-3.png"); ?>);background-position: 50% -13px;color:#fff;">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
					<h4>MOVING WITH US</h4>
					<h1 class="h1">How We Work?</h1>
					 <img src="<?php echo base_url("resource/images/slider/h1-slide2-separator-light.png"); ?>" alt="" class="animated fadeInUp" data-animation-effect="fadeInUp" data-effect-delay="400">				
					<br><br><br>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 text-center animated bounceInLeft" id="one">
					<img src="<?php echo base_url("resource/images/h1-process-img-1.png"); ?>" alt="">
					<h3>Register</h3>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 text-center animated bounceInLeft" id="two">
					<img src="<?php echo base_url("resource/images/h1-process-img-2.png"); ?>" alt="">
					<h3>Make An Order</h3>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 text-center animated bounceInLeft" id="three">
					<img src="<?php echo base_url("resource/images/h1-process-img-3.png"); ?>" alt="">
					<h3>We arrive ASAP</h3>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 text-center animated bounceInLeft" id="four">
					<img src="<?php echo base_url("resource/images/h1-process-img-4.png"); ?>" alt="">
					<h3> Sit Back & Relax </h3>
				</div>
			</div>
		</div>
	</section>