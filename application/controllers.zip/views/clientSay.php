<section style="background-image: url(<?php echo base_url("resource/images/h1-parallax-2.png"); ?>);padding-top: 30px;" class="mkd-parallax-section-holder">
		<div class="container">			
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
					<h1 class="h1">What our clients say</h1>
					<div class="mkd-separator-holder clearfix">
						<div class="mkd-separator" style="border-color: #f05034;border-style: solid;width: 75px;border-bottom-width: 2px"></div>
					</div>
					<h4>Daily&nbsp;Delivery Specialists For Personal or Business Clients</h4>
					<br><br><br>
				</div>
			</div>
			<div class="row hidden-xs" style="color:#fff;">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
					<div id="carousel-example-generic" class="carousel1 slide" data-ride="carousel">
					  <!-- Wrapper for slides -->
					  <div class="carousel-inner" role="listbox">
					    <div class="item active">					      
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
								<div class="row custom-text well" style="padding: 0px;border: 0px;background-color: rgba(20,22,24,0.6);">
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center custom-p">
										<p class="custom-text-2">Thank you for being so professional and easing my product delivery. We would love to use ASAP for the future. <br> &nbsp; </p>
									</div>
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center custom-p" style="background-color:#f05034;padding: 10px;">						
										<div class="mkd-testimonial-info">
											<div class="mkd-testimonial-author-image">
												<img width="50" height="50" src="<?php echo base_url("resource/images/avatar5.png"); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="a">
											</div>
											<h5 class="mkd-testimonial-author-text">
												Dola
											</h5>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
								<div class="row custom-text well" style="padding: 0px;border: 0px;background-color: rgba(20,22,24,0.6);">
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center custom-p">
										<p class="custom-text-2">I have not come across another company who offer the level of service and professionalism that ASAP do. It’s a pleasure to work alongside them</p>
									</div>
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center custom-p" style="background-color:#f05034;padding: 10px;">						
										<div class="mkd-testimonial-info">
											<div class="mkd-testimonial-author-image">
												<img width="50" height="50" src="<?php echo base_url("resource/images/avatar5.png"); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="a">
											</div>
											<h5 class="mkd-testimonial-author-text">
												Rashed
											</h5>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
								<div class="row custom-text well" style="padding: 0px;border: 0px;background-color: rgba(20,22,24,0.6);">
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center custom-p">
										<p class="custom-text-2">I was really impressed with your service. Everything was arranged in time, and you guys informed throughout.Thank you so much</p>
									</div>
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center custom-p" style="background-color:#f05034;padding: 10px;">						
										<div class="mkd-testimonial-info">
											<div class="mkd-testimonial-author-image">
												<img width="50" height="50" src="<?php echo base_url("resource/images/avatar5.png"); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="a">
											</div>
											<h5 class="mkd-testimonial-author-text">
												Obhi
											</h5>
										</div>
									</div>
								</div>
							</div>
					    </div>
					  </div>
					</div>
				</div>
			</div>
			<div class="row visible-xs hidden-lg" style="color:#fff;">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
					<div id="carousel-example-generic" class="carousel1 slide" data-ride="carousel">
					  <!-- Wrapper for slides -->
					  <div class="carousel-inner" role="listbox">
					    <div class="item active">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
								<div class="row custom-text well" style="padding: 0px;border: 0px;background-color: rgba(20,22,24,0.6);">
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center custom-p">
										<p class="custom-text-2">Thank you for being so professional and easing my product delivery. We would love to use ASAP for the future.</p>
									</div>
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center custom-p" style="background-color:#f05034;padding: 10px;">						
										<div class="mkd-testimonial-info">
											<div class="mkd-testimonial-author-image">
												<img width="50" height="50" src="<?php echo base_url("resource/images/avatar5.png"); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="a">
											</div>
											<h5 class="mkd-testimonial-author-text">
												Dola
											</h5>
											<div class="mkd-testimonials-job">
												Analyst
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
								<div class="row custom-text well" style="padding: 0px;border: 0px;background-color: rgba(20,22,24,0.6);">
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center custom-p">
										<p class="custom-text-2">I have not come across another company who offer the level of service and professionalism that ASAP do.It’s a pleasure to work alongside them</p>
									</div>
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center custom-p" style="background-color:#f05034;padding: 10px;">						
										<div class="mkd-testimonial-info">
											<div class="mkd-testimonial-author-image">
												<img width="50" height="50" src="<?php echo base_url("resource/images/avatar5.png"); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="a">
											</div>
											<h5 class="mkd-testimonial-author-text">
												Rashed
											</h5>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
								<div class="row custom-text well" style="padding: 0px;border: 0px;background-color: rgba(20,22,24,0.6);">
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center custom-p">
										<p class="custom-text-2">I was really impressed with your service.Everything was arranged in time, and you guys informed throughout.Thank you so much</p>
									</div>
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center custom-p" style="background-color:#f05034;padding: 10px;">						
										<div class="mkd-testimonial-info">
											<div class="mkd-testimonial-author-image">
												<img width="50" height="50" src="<?php echo base_url("resource/images/avatar5.png"); ?>" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="a">
											</div>
											<h5 class="mkd-testimonial-author-text">
												Obhi
											</h5>
										</div>
									</div>
								</div>
							</div>
					    </div>
					  </div>
					</div>
				</div>
			</div>
		</div>
	</section>