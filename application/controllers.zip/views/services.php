<section id="Services" class="mkd-parallax-section-holder" style="background: #eee;background-position: 50% -13px;">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
					<h1 class="h1">Our Services</h1>
					<div class="mkd-separator-holder clearfix">
						<div class="mkd-separator" style="border-color: #f05034;border-style: solid;width: 75px;border-bottom-width: 2px"></div>
					</div>
					<br> &nbsp; <br>
				</div>
			</div>
			<div class="row" style="background-color: #fff;">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="row" style="background-color: #fff;">
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="padding: 0px;margin: 0px">
							<div class="box-border-inner">
								<h6 class="box-title-text">Free of cost pickup </h6>
								<p class="box-body-text"> We only charge for the delivery. </p>						
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="padding: 0px;margin: 0px">
							<div class="box-border-inner">
								<h6 class="box-title-text"> Spot tracking </h6>
								<p class="box-body-text"> 	You can easily track parcel’s delivery status. </p>						
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="padding: 0px;margin: 0px">
							<div class="box-border-inner">
								<h6 class="box-title-text"> Fast and reliable parcel delivery </h6>
								<p class="box-body-text"> Quickness and reliability is our foundation. </p>						
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="padding: 0px;margin: 0px">
							<div class="box-border-inner">
								<h6 class="box-title-text"> Fast and reliable document delivery </h6>
								<p class="box-body-text"> Have no worry about sensitive documents. </p>						
							</div>
						</div>
					</div>
					<div class="row" style="background-color: #ededed;">
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="padding: 0px;margin: 0px">
							<div class="box-border-inner">
								<h6 class="box-title-text"> Online based ordering system </h6>
								<p class="box-body-text"> Super easy to use and order.  </p>						
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="padding: 0px;margin: 0px">
							<div class="box-border-inner">
								<h6 class="box-title-text"> Customer support </h6>
								<p class="box-body-text"> 	Get in touch with us for any sort of query. </p>						
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="padding: 0px;margin: 0px">
							<div class="box-border-inner">
								<h6 class="box-title-text"> Same day delivery </h6>
								<p class="box-body-text"> Two packages for your convenience – Lightning & Speedy. </p>						
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="padding: 0px;margin: 0px">
							<div class="box-border-inner">
								<h6 class="box-title-text"> Bulk delivery </h6>
								<p class="box-body-text"> Bulk cannot ‘Hulk’ us. </p>						
							</div>
						</div>
					</div>
					<div class="row" style="background-color: #fff;">
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="padding: 0px;margin: 0px">
							<div class="box-border-inner">
								<h6 class="box-title-text"> Online inventory support </h6>
								<p class="box-body-text"> No extra charge, no need to spend for your own inventory software. </p>						
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="padding: 0px;margin: 0px">
							<div class="box-border-inner">
								<h6 class="box-title-text"> Online bookkeeping </h6>
								<p class="box-body-text"> Again no extra charge, only for your convenience </p>						
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="padding: 0px;margin: 0px">
							<div class="box-border-inner">
								<h6 class="box-title-text"> Online earnings tracker </h6>
								<p class="box-body-text"> Takes your entire headache away. </p>						
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" style="padding: 0px;margin: 0px">
							<div class="box-border-inner">
								<h6 class="box-title-text"> Online delivery notifications</h6>
								<p class="box-body-text"> As soon as the delivery is made.</p>						
							</div>
						</div>
					</div>
				</div> 	
				</div>
			</div>
		</div>
	</section>